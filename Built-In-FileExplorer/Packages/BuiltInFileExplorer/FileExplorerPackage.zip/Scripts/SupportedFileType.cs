public enum SupportedFileType
{
    mp3,
    mp4,
    png,
    jpg,
    jpeg,
    dir,
    noExtension
}
